# DIT637-TT02
Follow the instructions inside "(Start Here) TT02A Experiencing Cloud Computing – Full-Stack Mobile App.pdf"

# Quick Start

```
npx expo login
npm install 
npx expo start --tunnel
```

Open Expo Go App in your Phone

## Expo Go

### Create Account
Sign Up here: https://expo.dev/

### Download in iOS or Android
Search Expo Go in App Store or Google Play Store

## ReactNative

This project is just a starting point for a dev.to tutorial that explains how to use GitHub Codespaces to develop React Native apps using [Expo](https://expo.io).

Check the tutorial below or in the link: TBD
